import { useDispatch } from "react-redux"
import { login, logout } from "../features/User"

const Login = () => {
    const dispatch = useDispatch()
    const user = {name: "John", age: 22, email: "john@gmail.com"}
    return (
        <div>
            <button onClick={() => dispatch(login(user))}>Login</button>
            <button onClick={() => dispatch(logout())}>Logout</button>
        </div>
    )
}

export default Login