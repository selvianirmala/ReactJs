import './App.css';
import Button from './components/Button';
import CounterComp from './components/CounterComp';
import Login from './components/Login';
import Profile from './components/Profile';


function App() {
  return (
    <div className="App">
      {/* <CounterComp/>
      <Button/> */}

      <Profile/>
      <Login/>

    </div>
  );
}

export default App;
